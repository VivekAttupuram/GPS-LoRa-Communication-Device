/**
 * @file app_init.h
 * @brief Application initialization
 */


#ifndef APP_INIT_H
#define APP_INIT_H

extern void app_init(void);

#endif // APP_INIT_H