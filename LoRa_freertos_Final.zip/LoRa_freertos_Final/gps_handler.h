/**
 * @file gps_handler.h
 * @brief GPS Handler task
 */

#ifndef GPS_HANDLER_H
#define GPS_HANDLER_H

#include "FreeRTOS.h"
#include "queue.h"

typedef struct
{
    QueueHandle_t gps_queue_handle;
    QueueHandle_t loramanager_queue_handle;
} gps_handler_params_t;

extern void gps_handler_task(void *pvParameters);

extern void gps_handler_isr(void);

#endif // GPS_HANDLER_H