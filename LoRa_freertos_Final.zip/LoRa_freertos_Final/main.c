/**
 * @file main.c
 * @brief Main entry point for our project.
 */

#include "FreeRTOS.h"
#include "task.h"

#include "app_init.h"

int main(void)
{
    app_init();            // initalize FreeRTOS tasks and signalling. "Connect them"
    vTaskStartScheduler(); // start FreeRTOS scheduler
}