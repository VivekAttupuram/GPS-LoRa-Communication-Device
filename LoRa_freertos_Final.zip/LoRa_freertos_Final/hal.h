/**
 * @file hal.h
 * @brief Hardware Abstraction Layer for our project.
 */

#ifndef HAL_H
#define HAL_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h> // for size_t

/// @brief Callback functions used in ISRs
typedef void (*hal_callback_func_t)(void);

/// @brief Initialzes the hardware used by this HAL
extern void hal_init(void);

/// @brief Checks if the GPS UART has data available to read.
/// @return True is data is available
extern bool hal_gps_is_readable(void);

/// @brief Reads a single character from the GPS UART.
/// @return he character read from the UART.
extern char hal_gps_getc(void);

/// @brief Register this func at the GPS UART ISR
/// @param gps_isr Function pointer to the ISR
extern void hal_gps_register_isr(hal_callback_func_t gps_isr);

/// @brief Enable/Disable the GPS UART IRQs
/// @param rx_enabled True to enable, false to disable.
extern void hal_gps_set_rx_irq(bool rx_enabled);

/// @brief Turn the white led on/off
/// @param on True for on, false for off
extern void hal_led_white_set(bool on);

/// @brief Turn the red led on/off
/// @param on True for on, false for off
extern void hal_led_red_set(bool on);

/// @brief Puts a char to io monitor/terminal. DO NOT USE IN ISR
/// @param  ch character to put to monitor/terminal
extern int hal_stdio_putchar(char ch);

/// @brief Our printf. Use this instead of <stdio.h>'s. DO NOT USE IN ISR
/// @param format
/// @param  ... variable list
/// @return The number of characters printed
extern int hal_printf(const char *format, ...);

// ============================================
// NEW NEW!!! Commands for talking over SPI to the LoRa. The are the functions sx126x_hal.c needs!

/// @brief Gets the value of the LoRa busy pin
/// @return true if high, false if low
extern bool hal_lora_busy_pin_get(void);

/// @brief Gets the value of the LoRa IRQ pin
/// @return true if high, false if low
extern bool hal_lora_irq_pin_get(void);

/// @brief Set the value of the LoRa NSS Pin
/// @param value True for high, false for low
extern void hal_lora_nss_pin_put(bool value);

/// @brief Write to the LoRa SPI
/// @param src Buffer of data to write
/// @param len Length of data to write
/// @return number of bytes written
extern int hal_lora_spi_write_blocking(const uint8_t *src, size_t len);

/// @brief Read from LoRa SPI
/// @param repeated_tx_data Value to write to SPI while reading
/// @param dst Buffer to put data that is read
/// @param len number of bytes to read
/// @return number of bytes read
extern int hal_lora_spi_read_blocking(uint8_t repeated_tx_data, uint8_t *dst, size_t len);

/// @brief Busy wait (cpu spinning)
/// @param delay_ms Time to wait
extern void hal_busy_wait_ms(uint32_t delay_ms);

/// @brief Set the value of the LoRa Reset Pin
/// @param value True for high, false for low
extern void hal_lora_reset_pin_put(bool value);

/// @brief Registers this callback to run when lora IRQ happens
/// @param lora_irq_callback pointer to function to run.
extern void hal_lora_register_isr(hal_callback_func_t lora_irq_callback);

extern uint32_t hal_get_rand_32(void);

#endif // HAL_H
