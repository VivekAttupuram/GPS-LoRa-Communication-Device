/*
NMEA parser example.
This is done in a way to expose the inner workings of the parser
as a learning exercise.

How to use:

1) Create a struct that will hold the data as it is processed.

nmea_GGA_t nmea_data;

2) Pass a single character at a time to the parser.

bool ret = nmea_parse(c, &nmea_data);

3) Check if ret==true. If so, the data in nmea_data corresponds to a complete GGA sentence.

if (ret==true)
{
   do something with the nmea_data struct
}


*/

#ifndef NMEA_H
#define NMEA_H

#include <stdbool.h>
#include <stdint.h>

/// @brief Defines the possible fix types in a GGA sentence
typedef enum
{
    NO_FIX = 0,
    GNSS_FIX = 1,
    DIFF_GNS_FIX = 2,
    RTK_FIX = 4,
    RTK_FLOAT = 5,
    DEADRECK_FIX = 6
} gps_fix_t;

/// @brief Holds the in-progress NMEA data parsed from a GGA sentence
typedef struct
{
    // in a struct, put biggest memory sizes first
    double lat;        // lattitude
    double lon;        // longitude
    float hdop;        // horizontal error
    float alt;         // altitude (in meters)
    gps_fix_t gps_fix; // type of fix
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint8_t hund_sec; // hundredths of second
    uint8_t num_sats;
    uint8_t checksum;  // received sentence checksum
    uint8_t checkcalc; // calculated checksum
    // the following uses "bitfields." A bool is 8 bits large
    // So we can use the C feature to store a binary 1 or 0 in a single bit below
    bool valid_checksum : 1;   // checksum is valid
    bool valid_gps_fix : 1;    // gps is valid
    bool valid_chksum_fix : 1; // true if both checksum and gps_fix are valid
} nmea_GGA_t;

// "extern" is technically not necessary below, but put it anyways.
// using extern makes it expicit that this is for public use

/// @brief Function that parses NMEA sentences one character at a time,
///        specifically looking for GGA sentences.
/// @param ch The character to parse
/// @param gga_data_p An object that holds the parsed GGA data.
/// @return True when there is new data. False while still processing.
extern bool nmea_parse(const char ch, nmea_GGA_t *const gga_data_p);

#endif // NMEA_H