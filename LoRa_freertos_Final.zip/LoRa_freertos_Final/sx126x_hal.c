#include "sx126x_hal.h"

#include "hal.h"

sx126x_hal_status_t sx126x_hal_write(const void *context,
                                     const uint8_t *command,
                                     const uint16_t command_length,
                                     const uint8_t *data,
                                     const uint16_t data_length)
{
    (void)context; // unused!
    while (hal_lora_busy_pin_get())
    {
        // placeholder for don't do anything
    }
    hal_lora_nss_pin_put(false);                          // Chip select goes low
    hal_lora_spi_write_blocking(command, command_length); // send command_length bytes from command over SPI, ignoring any incoming data
    hal_lora_spi_write_blocking(data, data_length);       // send data_length bytes from data over SPI, ignoring any incoming data
    hal_lora_nss_pin_put(true);                           // Chip select goes high
    return SX126X_HAL_STATUS_OK;
}

sx126x_hal_status_t sx126x_hal_read(const void *context,
                                    const uint8_t *command,
                                    const uint16_t command_length,
                                    uint8_t *data,
                                    const uint16_t data_length)
{
    (void)context;                  // unused!
    while (hal_lora_busy_pin_get()) // asserts high if it's busy.
    {
        // placeholder for don't do anything
    }
    hal_lora_nss_pin_put(false);                               // Chip select goes low
    hal_lora_spi_write_blocking(command, command_length);      // send command_length bytes from command over SPI, ignoring any incoming data
    hal_lora_spi_read_blocking(SX126X_NOP, data, data_length); // send data_length bytes of 0s while putting data_length bytes of data in to data
    hal_lora_nss_pin_put(true);                                // Chip select goes high
    return SX126X_HAL_STATUS_OK;
}

sx126x_hal_status_t sx126x_hal_reset(const void *context)
{
    (void)context;                 // unused!
    hal_lora_reset_pin_put(false); // reset pin goes low
    hal_busy_wait_ms(1);           // wait at least 100 us
    hal_lora_reset_pin_put(true);  // reset pin goes high
    hal_busy_wait_ms(4);           // wait for radio to reset/warm up the oscillator
    return SX126X_HAL_STATUS_OK;
}

sx126x_hal_status_t sx126x_hal_wakeup(const void *context)
{
    (void)context;               // unused!
    hal_lora_nss_pin_put(false); // Chip select goes low
    hal_busy_wait_ms(1);         // wait at least 100 us
    hal_lora_nss_pin_put(true);  // Chip select goes high
    return SX126X_HAL_STATUS_OK;
}
