#include "hal.h"

#include "FreeRTOS.h"
#include "semphr.h"

#include "pico/stdio.h"
#include "pico/stdio_usb.h"
#include "pico/rand.h"
#include "hardware/uart.h"
#include "hardware/gpio.h"
#include "hardware/irq.h"
#include "hardware/timer.h"
#include "hardware/clocks.h"
#include "hardware/spi.h"

#define GPS_UART_ID uart0
#define GPS_UART_IRQ_ID UART0_IRQ
#define GPS_BAUD_RATE 38400
#define GPS_UART_TX_PIN 16
#define GPS_UART_RX_PIN 17

#define LED_WHITE_PIN 24
#define LED_RED_PIN 23

// LoRa Pin Settings
#define LORA_NSS 10
#define LORA_IRQ 9
#define LORA_BUSY 15
#define LORA_SPI spi1
#define LORA_TX 11                        // SPI1
#define LORA_RX 12                        // SPI1
#define LORA_SCK 14                       // SPI1
#define LORA_RESET 8                      // resets when low for > 100 microsecs
#define LORA_CLOCK_RATE (16 * 1000 * 1000) // should be < 16 MHz
// end Lora pin settings

// FreeRTOS objects to be used by this HAL

// our stdio mutex, so only one thing uses stdio at a time.
// https://www.freertos.org/Documentation/02-Kernel/04-API-references/10-Semaphore-and-Mutexes/07-xSemaphoreCreateMutexStatic
static SemaphoreHandle_t stdio_mutex = NULL;
static StaticSemaphore_t stdio_mutex_buffer;

static void on_lora_irq_generic(uint gpio, uint32_t event_mask);
static void (*s_lora_irq_callback)(void) = NULL;

void hal_init(void)
{
    // set up stdio
    stdio_init_all();
#ifdef LIB_PICO_STDIO_USB
    while (stdio_usb_connected())
    {
        // take some time to connect to USB if you have one
    }
#endif

    gpio_set_function(GPS_UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(GPS_UART_RX_PIN, GPIO_FUNC_UART);
    uart_init(GPS_UART_ID, GPS_BAUD_RATE);
    irq_set_enabled(GPS_UART_IRQ_ID, true);

    gpio_init(LED_WHITE_PIN);
    gpio_set_dir(LED_WHITE_PIN, GPIO_OUT);
    gpio_init(LED_RED_PIN);
    gpio_set_dir(LED_RED_PIN, GPIO_OUT);

    // set up LoRa pins
    spi_init(LORA_SPI, LORA_CLOCK_RATE); // set up SPI. Defaults Motorola CPOL=0, CPHA=0
    gpio_set_function(LORA_TX, GPIO_FUNC_SPI);
    gpio_set_function(LORA_RX, GPIO_FUNC_SPI);
    gpio_set_function(LORA_SCK, GPIO_FUNC_SPI);

    // Chip select is active-low, so we'll initialise it to a driven-high state
    gpio_init(LORA_NSS);
    gpio_set_dir(LORA_NSS, GPIO_OUT);
    gpio_put(LORA_NSS, 1);

    // initialize IRQ pin, defaults to input mode
    // we'll have to attach the ISR later
    gpio_init(LORA_IRQ);
    // tell our micrcontroller to use a GPIO pin to look for interrupts
    gpio_set_irq_enabled_with_callback(LORA_IRQ,              // set up this pin as interrupt pin
                                       GPIO_IRQ_EDGE_RISE,    // on rising edge, triger interrupt
                                       true,                  // enable it immediately
                                       &on_lora_irq_generic); // run this function when irq happens

    // initialize the reset pin. Setting to 1 turns the LoRa module on.
    gpio_init(LORA_RESET);
    gpio_set_dir(LORA_RESET, GPIO_OUT);
    gpio_set_dir(LORA_RESET, GPIO_OUT);
    gpio_put(LORA_RESET, 0); // force a reset on initialization
    busy_wait_ms(1);
    gpio_put(LORA_RESET, 1);
    busy_wait_ms(4); // wait 4 milliseconds for radio to warm up (data sheet suggests this)

    // set up the

    // init freertos objects
    stdio_mutex = xSemaphoreCreateMutexStatic(&stdio_mutex_buffer); // mutex to protect STDIO
}

bool hal_gps_is_readable(void)
{
    return uart_is_readable(GPS_UART_ID);
}

char hal_gps_getc(void)
{
    return uart_getc(GPS_UART_ID);
}

void hal_gps_register_isr(void (*gps_isr)(void))
{
    irq_set_exclusive_handler(GPS_UART_IRQ_ID, gps_isr);
}

void hal_gps_set_rx_irq(bool rx_enabled)
{
    uart_set_irqs_enabled(GPS_UART_ID, rx_enabled, false);
}

void hal_busy_wait_ms(uint32_t delay_ms)
{
    busy_wait_ms(delay_ms);
}

void hal_led_white_set(bool on)
{
    gpio_put(LED_WHITE_PIN, on);
}

void hal_led_red_set(bool on)
{
    gpio_put(LED_RED_PIN, on);
}

int hal_stdio_putchar(char ch)
{
    int ret = -1;
    if (xSemaphoreTake(stdio_mutex, pdMS_TO_TICKS(250)) == pdTRUE)
    {
        ret = stdio_putchar(ch); // do something
        xSemaphoreGive(stdio_mutex);
    }
    return ret;
}

int hal_printf(const char *format, ...)
{
    // The only thing to know about this is that it uses a mutex
    // THE REST OF THE IMPLEMENTATION IS OUTSIDE OF THE SCOPE OF THE CLASS
    int ret = 0;
    // gpio_put(25, true);

    if (xSemaphoreTake(stdio_mutex, pdMS_TO_TICKS(250)) == pdTRUE)
    {
        va_list args;

        // 1. Initialize the va_list to capture the '...' arguments.
        va_start(args, format);

        // 2. Call the vprintf function pointer from our driver,
        //    passing the va_list through.
        ret = stdio_vprintf(format, args);

        // 3. Clean up the va_list.
        va_end(args);
        xSemaphoreGive(stdio_mutex);
    }
    return ret;
}

bool hal_lora_busy_pin_get(void)
{
    return gpio_get(LORA_BUSY);
}

bool hal_lora_irq_pin_get(void)
{
    return gpio_get(LORA_IRQ);
}

void hal_lora_nss_pin_put(bool value)
{
    gpio_put(LORA_NSS, value);
}

int hal_lora_spi_write_blocking(const uint8_t *src, size_t len)
{
    return spi_write_blocking(LORA_SPI, src, len);
    ;
}

int hal_lora_spi_read_blocking(uint8_t repeated_tx_data, uint8_t *dst, size_t len)
{
    return spi_read_blocking(LORA_SPI, repeated_tx_data, dst, len);
}

void hal_lora_reset_pin_put(bool value)
{
    gpio_put(LORA_RESET, value);
}

uint32_t hal_get_rand_32(void)
{
    return get_rand_32();
}

void hal_lora_register_isr(void (*lora_irq_callback)(void))
{
    s_lora_irq_callback = lora_irq_callback;
}

void on_lora_irq_generic(uint gpio, uint32_t event_mask)
{
    (void)event_mask; // not needed for us
    if (gpio == LORA_IRQ && s_lora_irq_callback != NULL)
    {
        s_lora_irq_callback();
    }
}
