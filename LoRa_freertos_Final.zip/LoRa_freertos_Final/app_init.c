/**
 * @file app_init.c
 * @brief Application initialization
 */

#include "app_init.h"

#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"
#include "queue.h"

#include "hal.h"
#include "gps_handler.h"
#include "task_monitor.h"
#include "lora.h"

// STEP 0: Configuration for our application
#define TASK_MONITOR_ENABLED 1 // set to 1 to enable the task monitor, 0 to disable

// STEP 1: Allocate all memory needed for different objects: tasks + inter-task communications
// every queue and task needs a "buffer" struct, and data storage - just like our FIFOs!
// for organization, things that need to be static are made file static
#define GPS_QUEUE_LENGTH 64
#define GPS_QUEUE_ITEM_SIZE sizeof(char)
static uint8_t gps_queue_storage[GPS_QUEUE_LENGTH * GPS_QUEUE_ITEM_SIZE];
static StaticQueue_t gps_queue_buffer;

#define LORAMANAGER_QUEUE_LENGTH 8
#define LORAMANAGER_QUEUE_ITEM_SIZE sizeof(lora_msg_t)
static uint8_t loramanager_queue_storage[LORAMANAGER_QUEUE_LENGTH * LORAMANAGER_QUEUE_ITEM_SIZE];
static StaticQueue_t loramanager_queue_buffer;

#define GPS_HANDLER_STACK_SIZE (configMINIMAL_STACK_SIZE + 256) // Stack size in words (4 bytes/word) configMINIMAL_STACK_SIZE = 256 words
static StackType_t gps_handler_stack[GPS_HANDLER_STACK_SIZE];
static StaticTask_t gps_handler_buffer;
static gps_handler_params_t gps_handler_params; // the struct passed to the gps_handler task

#define LORA_MANAGER_STACK_SIZE (configMINIMAL_STACK_SIZE + 256) // Stack size in words (4 bytes/word) configMINIMAL_STACK_SIZE = 256 words
static StackType_t lora_manager_stack[LORA_MANAGER_STACK_SIZE];
static StaticTask_t lora_manager_buffer;
// static gps_handler_params_t gps_handler_params; // the struct passed to the gps_handler task

#if TASK_MONITOR_ENABLED == 1
#define TASK_MONITOR_STACK_SIZE (configMINIMAL_STACK_SIZE + 256) // size is this times 32 bytes large. 256 is minimum
static StackType_t task_monitor_stack[TASK_MONITOR_STACK_SIZE];
static StaticTask_t task_monitor_buffer;
static task_monitor_params_t task_monitor_params;
#endif // TASK_MONITOR_ENABLED==1

void app_init(void)
{
    // STEP 2: Initialize the hall and connect anything the hardware needs to know from the app layer
    //         For example, register the application's ISRs for the hardware.
    hal_init();
    hal_gps_register_isr(&gps_handler_isr);
    hal_lora_register_isr(&lora_isr_callback);

    //  STEP 3: create all the inter-task communications needed and tasks needed.
    //          Make handles for queues that will be needed for inter-task communications.
    //          Handles should be dynamic/local, not static
    QueueHandle_t gps_queue_handle = xQueueCreateStatic(GPS_QUEUE_LENGTH,    // num of elements
                                                        GPS_QUEUE_ITEM_SIZE, // size of each element in bytes
                                                        gps_queue_storage,   // storage queue
                                                        &gps_queue_buffer);  // control buffer

    QueueHandle_t loramanager_queue_handle = xQueueCreateStatic(LORAMANAGER_QUEUE_LENGTH,    // num of elements
                                                                LORAMANAGER_QUEUE_ITEM_SIZE, // size of each element in bytes
                                                                loramanager_queue_storage,   // storage queue
                                                                &loramanager_queue_buffer);  // control buffer

    // STEP 3: For each task: Populate any param structs to be passed to the tasks & create tasks,
    //         giving the tasks a pointer to their own param struct or queue handle. Make handles for tasks if needed.
    gps_handler_params.gps_queue_handle = gps_queue_handle;
    gps_handler_params.loramanager_queue_handle = loramanager_queue_handle;
    TaskHandle_t gps_handler_task_handle = xTaskCreateStatic(&gps_handler_task,      /* Function that implements the task. */
                                                             "GPS Handler",          /* Text name for the task. */
                                                             GPS_HANDLER_STACK_SIZE, /* Number of indexes in the xStack array. */
                                                             &gps_handler_params,    /* Parameter passed into the task. */
                                                             tskIDLE_PRIORITY + 2,   /* Priority at which the task is created. */
                                                             gps_handler_stack,      /* Array to use as the task's stack. */
                                                             &gps_handler_buffer);   /* Variable to hold the task's data structure. */

    TaskHandle_t lora_manager_handle = xTaskCreateStatic(&lora_manager,            /* Function that implements the task. */
                                                         "LoRa Manager",           /* Text name for the task. */
                                                         LORA_MANAGER_STACK_SIZE,  /* Number of indexes in the xStack array. */
                                                         loramanager_queue_handle, /* Parameter passed into the task. We just need the queue handle*/
                                                         tskIDLE_PRIORITY + 1,     /* Priority at which the task is created. */
                                                         lora_manager_stack,       /* Array to use as the task's stack. */
                                                         &lora_manager_buffer);    /* Variable to hold the task's data structure. */

#if TASK_MONITOR_ENABLED == 1
    task_monitor_params.task_array[0] = gps_handler_task_handle;
    task_monitor_params.task_array[1] = lora_manager_handle;
    task_monitor_params.num_tasks = 2;
    xTaskCreateStatic(&task_monitor_task,      /* Function that implements the task. */
                      "Task Monitor",          /* Text name for the task. */
                      TASK_MONITOR_STACK_SIZE, /* Number of indexes in the xStack array. */
                      &task_monitor_params,    /* Parameter passed into the task. */
                      tskIDLE_PRIORITY,        /* Priority at which the task is created. */
                      task_monitor_stack,      /* Array to use as the task's stack. */
                      &task_monitor_buffer);   /* Variable to hold the task's data structure. */

#endif // TASK_MONITOR_ENABLED==1
}

// This actually puts it to sleep when the application goes idle
void vApplicationIdleHook(void)
{
    hal_led_white_set(false);
    __wfi();
    hal_led_white_set(true);
}