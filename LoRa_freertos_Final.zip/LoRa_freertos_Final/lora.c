#include "lora.h"

#include <string.h>
#include <stddef.h> // for NULL

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "sx126x.h"
#include "hal.h"

// APPLICATION CONFIGURATION SETINGS
#define MY_ID_NUMBER 49 
#define LORA_FREQ_IN_HZ (910 * 1000 * 1000)     // 910 MHz
#define LORA_ACK_FREQ_IN_HZ (905 * 1000 * 1000) // 905 MHz
#define LORA_POWER_IN_DBM 22                    // 22 dBm is max power. only use this (IC optimized for this)
#define LORA_RAMP_TIME SX126X_RAMP_200_US       // 200 microsecs power up time
// set IRQS for RX done TX done and timeout
#define LORA_IRQS_ENABLED (SX126X_IRQ_RX_DONE | SX126X_IRQ_TX_DONE | SX126X_IRQ_TIMEOUT)
#define LORA_PREAMBLE_LEN 12         // how long to "BEEP" at the beginning of transmission to wake up receivers. 12 symbols, nice default
#define LORA_RX_BOOST true           // enable RX boosting. more sensitivity, but more power consumption
#define LORA_SF SX126X_LORA_SF7      // spreading factor 7
#define LORA_BW SX126X_LORA_BW_125   // 125kHz
#define LORA_CR SX126X_LORA_CR_4_5   // 4/5 Coding rate
#define LORA_INIT_RX_TIMEOUT_MS 5000 // The initial reception timeout
#define TX_SLOT_TIME 100             // in ms
// END APPLICATION CONFIGURATION SETINGS

// Constant Structs to be used in initialization

// Upload specific details about how we want to modulate (encode) our data
// both receiver and transmitter need the same settings
static const sx126x_mod_params_lora_t lora_mod_params = {
    .sf = LORA_SF, // spreading factor
    .bw = LORA_BW, // bandwidth
    .cr = LORA_CR, // coding rate
    .ldro = 0      // low data rate optimization
};

// Power Amplifier parameters
// Taken from the datasheet, optimal for sx1262 at 22 dBm
static const sx126x_pa_cfg_params_t pa_params = {
    .pa_duty_cycle = 0x04u,
    .hp_max = 0x07u,
    .device_sel = 0x00u,
    .pa_lut = 0x01u,
};

/// @brief Possible LoRa states
typedef enum
{
    IDLE,       //< Sits in RX mode listenginf for incoming packets and for TX requests
    TX_MODE,    //< currently actively transmitting a packet
    TX_ACK_WAIT // waiting to hear from station an ACK
} lora_state_t;

// file static functions

/// @brief set up LoRa and turn in on RX mode
/// @return true on error, false on success
static bool lora_init(void);

/// @brief Transmit a lora_packet_t over LoRa.
/// @param[in] packet packet structure containing data to TX
/// @return true on error, false on success
static bool lora_tx(const lora_packet_t *const packet);

/// @brief Gets the RX data from LoRa. Run this after RX done IRQ received
/// @param[out] packet packet structure to place data
/// @param[out] pkt_status RSSI info from packet
/// @return true on error, false on success
static bool lora_rx(lora_packet_t *const packet, sx126x_pkt_status_lora_t *const pkt_status);

/// @brief Gets the current IRQ status of the LoRa module and clears all IRQs
/// @param[out] irqsp A pointer to an sx126x_irq_mask_t to hold the current IRQs
/// @return Command status returned from LoRA
static sx126x_status_t lora_get_and_clear_irq_status(sx126x_irq_mask_t *const irqsp);

/// @brief Set the LoRa module to RX mode with a timeout
/// @param[in] timeout_in_ms Requested timeout
/// @return Status (0 on success)
static sx126x_status_t lora_set_rx(const uint32_t timeout_in_ms);

// static queue so we can use it in the ISR!
static QueueHandle_t loramanager_queue_handle = NULL;

void lora_manager(void *pvParameters)
{
    loramanager_queue_handle = (QueueHandle_t)pvParameters;
    lora_init();
    lora_state_t lora_state = IDLE;
    lora_msg_t msg;
    uint8_t error_count;
    lora_packet_t last_packet;
    while (1)
    {
        xQueueReceive(loramanager_queue_handle, &msg, portMAX_DELAY);
        switch (lora_state)
        {
        case IDLE:
            if (msg.event == TX_REQ_EVENT)
            {
                last_packet = msg.pkt;
                lora_tx(&msg.pkt);
                error_count = 0;
                hal_led_red_set(true);
                lora_state = TX_MODE;
            }
            else if (msg.event == IRQ_EVENT)
            {
                sx126x_irq_mask_t irqs;
                lora_get_and_clear_irq_status(&irqs);

                // Do the following depending on which IRQ fired.
                if ((irqs & SX126X_IRQ_RX_DONE) == SX126X_IRQ_RX_DONE)
                {
                    hal_printf("Interrupt: RX done\n");
                    lora_packet_t pkt;
                    sx126x_pkt_status_lora_t status;
                    lora_rx(&pkt, &status);
                    hal_printf("RSSI: %d dBm  SNR: %d dB\n", status.rssi_pkt_in_dbm, status.snr_pkt_in_db);
                    for (int i = 0; i < pkt.len; i++)
                    {
                        hal_printf("%c", pkt.data[i]);
                    }
                    hal_printf("\nHex:");
                    for (int i = 0; i < pkt.len; i++)
                    {
                        hal_printf(" 0x%02X", pkt.data[i]);
                    }
                    hal_printf("\n");
                    uint8_t rx_sn = 0;
                    double rx_lat = 0;
                    double rx_lon = 0;
                    memcpy(&rx_sn, &pkt.data[0], 1);
                    memcpy(&rx_lat, &pkt.data[1], 8);
                    memcpy(&rx_lon, &pkt.data[9], 8);
                    hal_printf("RX DATA!! SN: %d LAT: %f LONG: %f\n", rx_sn, rx_lat, rx_lon);
                    lora_set_rx(LORA_INIT_RX_TIMEOUT_MS);
                }
                if ((irqs & SX126X_IRQ_TIMEOUT) == SX126X_IRQ_TIMEOUT)
                {
                    hal_printf("Interrupt: Timeout\n");
                    lora_set_rx(LORA_INIT_RX_TIMEOUT_MS);
                }
            }
            break;
        case TX_MODE:
            if (msg.event == IRQ_EVENT)
            {
                sx126x_irq_mask_t irqs;
                lora_get_and_clear_irq_status(&irqs);

                // Do the following depending on which IRQ fired.
                if ((irqs & SX126X_IRQ_TX_DONE) == SX126X_IRQ_TX_DONE)
                {
                    // hal_printf("TX_DONE!\n");
                    hal_led_red_set(false);
                    sx126x_set_rf_freq(NULL, LORA_ACK_FREQ_IN_HZ);
                    lora_set_rx(TX_SLOT_TIME);
                    lora_state = TX_ACK_WAIT;
                }
                else
                {
                    hal_printf("got unknown IRQ while waiting for TX_DONE: 0x%X\n", irqs);
                }
            }
            else
            {
                hal_printf("Ignoring TX request. Already transmitting.\n");
            }
            break;

        case TX_ACK_WAIT:
            if (msg.event == IRQ_EVENT)
            {
                sx126x_irq_mask_t irqs;
                lora_get_and_clear_irq_status(&irqs);
                bool ack_confirmed=false;
                if ((irqs & SX126X_IRQ_RX_DONE) == SX126X_IRQ_RX_DONE)
                {
                    hal_printf("Interrupt: RX done\n");
                    lora_packet_t pkt;
                    sx126x_pkt_status_lora_t status;
                    lora_rx(&pkt, &status);
                    uint8_t ACK_ID=0;
                    memcpy(&ACK_ID,&pkt.data[0],1);
                    hal_printf("acked ID: %u\n",ACK_ID);
                    ack_confirmed = (ACK_ID==MY_ID_NUMBER);
                }

                if (((irqs & SX126X_IRQ_TIMEOUT) == SX126X_IRQ_TIMEOUT)||(!ack_confirmed))
                {
                    error_count++;
                    sx126x_set_rf_freq(NULL, LORA_FREQ_IN_HZ);
                    uint32_t delay = TX_SLOT_TIME * (hal_get_rand_32() >> (32 - error_count));
                    vTaskDelay(pdMS_TO_TICKS(delay));
                    lora_tx(&last_packet);
                    hal_led_red_set(true);
                    lora_state = TX_MODE;
                }
                else if (ack_confirmed)
                {
                    sx126x_set_rf_freq(NULL, LORA_FREQ_IN_HZ);
                    lora_set_rx(LORA_INIT_RX_TIMEOUT_MS);
                    lora_state=IDLE;

                }
            }
            else
            {
                hal_printf("TX_ACK_WAIT got event it doesn't handle\n");
            }
            break;
        default:
            while (1)
            {
                hal_printf("Unknown state in lora.c\n");
            }
            break;
        }
    }
}

void lora_isr_callback(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    lora_msg_t msg = {.event = IRQ_EVENT}; // leaving pkt unintialized is fine, we won't use it
    xQueueSendFromISR(loramanager_queue_handle, &msg, &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

bool lora_init(void)
{
    // see datasheet 15.2. Workaround for a bug on the chip
    // increases output power by as much as 6 dBm
    uint8_t read_byte;
    sx126x_read_register(NULL, 0x08D8u, &read_byte, 1);
    read_byte = read_byte | 0x1Eu;
    sx126x_write_register(NULL, 0x08D8u, &read_byte, 1);

    // Set up the radio!
    sx126x_set_pkt_type(NULL, SX126X_PKT_TYPE_LORA); // tell it we want to use LoRa. need to do this first
    sx126x_set_rf_freq(NULL, LORA_FREQ_IN_HZ);       // tell the radio the frequency we're using
    sx126x_set_pa_cfg(NULL, &pa_params);             // power amplifier settings

    // set the power level and transmitter ramp up time
    sx126x_set_tx_params(NULL, LORA_POWER_IN_DBM, LORA_RAMP_TIME);

    sx126x_set_lora_mod_params(NULL, &lora_mod_params);

    // Our module uses a radio frequency switch to switch between RX and TX
    // so we tell the radio chip that it can use it
    sx126x_set_dio2_as_rf_sw_ctrl(NULL, true);

    // enable RX boost (10% higher current, maybe better performance)
    // not sure if it's worth it, but we can give it a shot
    sx126x_cfg_rx_boosted(NULL, LORA_RX_BOOST);

    // next, set up which IRQs will fire
    // and what pins they will be sent to
    sx126x_set_dio_irq_params(NULL,
                              LORA_IRQS_ENABLED, // enable these interrupts
                              LORA_IRQS_ENABLED, // DIO1 will go high for these interrupts
                              SX126X_IRQ_NONE,   // DIO2 will not go high for any interrupt
                              SX126X_IRQ_NONE);  // DIO3 will not go high for any interrupt

    // upload the parameters for the data packet
    sx126x_pkt_params_lora_t lora_pkt_params = {
        .preamble_len_in_symb = LORA_PREAMBLE_LEN, // default is 12
        .header_type = SX126X_LORA_PKT_EXPLICIT,   // maybe use implicit to save bytes
        .pld_len_in_bytes = 0,                     // only used in TX and implicit RX mode
        .crc_is_on = true,                         // in case anyone wants to check
        .invert_iq_is_on = false};
    sx126x_set_lora_pkt_params(NULL, &lora_pkt_params); // upload the packet settings
    sx126x_set_rx(NULL, LORA_INIT_RX_TIMEOUT_MS);       // set it to rx mode
    // sx126x_set_rx_with_timeout_in_rtc_step(lora_context, SX126X_RX_CONTINUOUS);
    return false;
}

bool lora_tx(const lora_packet_t *const packet)
{
    // put it into standby mode so we don't accidentally get
    // a received packet when we are transmitting
    sx126x_set_standby(NULL, SX126X_STANDBY_CFG_RC);
    // set the packet params for TX
    sx126x_pkt_params_lora_t lora_pkt_params = {
        .preamble_len_in_symb = LORA_PREAMBLE_LEN,
        .header_type = SX126X_LORA_PKT_EXPLICIT,
        .pld_len_in_bytes = packet->len, // our pld is "len" bytes long
        .crc_is_on = true,
        .invert_iq_is_on = false};

    // upload the packet parameters (number of bytes to TX)
    sx126x_set_lora_pkt_params(NULL, &lora_pkt_params);

    // uploade the data to transmit to the radio
    sx126x_write_buffer(NULL, 0, &packet->data[0], packet->len);

    // tell the radio to trasnmit!
    sx126x_set_tx(NULL, 0);
    return false;
}

bool lora_rx(lora_packet_t *const packet, sx126x_pkt_status_lora_t *const pkt_status)
{
    // create a variable to hold the memory address and size of the received data
    sx126x_rx_buffer_status_t rx_buffer_status;

    // ask the radio for the memory address and location of the data on the LoRa radio
    sx126x_get_rx_buffer_status(NULL, &rx_buffer_status);

    // Read the buffer
    sx126x_read_buffer(NULL,
                       rx_buffer_status.buffer_start_pointer, // start reading here
                       packet->data,                          // put data here
                       rx_buffer_status.pld_len_in_bytes);    // read this many bytes
    packet->len = rx_buffer_status.pld_len_in_bytes;          // the buffer size

    sx126x_get_lora_pkt_status(NULL, pkt_status);
    return false;
}

sx126x_status_t lora_get_and_clear_irq_status(sx126x_irq_mask_t *const irqsp)
{
    return sx126x_get_and_clear_irq_status(NULL, irqsp);
}

sx126x_status_t lora_set_rx(const uint32_t timeout_in_ms)
{
    return sx126x_set_rx(NULL, timeout_in_ms);
}
