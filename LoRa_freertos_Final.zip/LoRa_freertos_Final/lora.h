#ifndef LORA_H
#define LORA_H

#include <stdbool.h>
#include <stdint.h>

/// @brief Struct for a LoRa packet
typedef struct
{
    uint8_t len;       //< how many bytes to send or were received. max of 255
    uint8_t data[255]; //< buffer to hold the data
} lora_packet_t;

/// @brief  Enum of the possible LoRa events
typedef enum {
    TX_REQ_EVENT,
    IRQ_EVENT
} lora_event_t;

/// @brief Message for LoRa Event queue, contains event + optional packet
typedef struct
{
    lora_event_t event;
    lora_packet_t pkt;
} lora_msg_t;

/// @brief The LoRa manager tasks
/// @param pvParameters A FreeRTOS queue_handle_t for the LoRa Event Queue
extern void lora_manager(void *pvParameters);

/// @brief the LoRa ISR. pushes an ISR event to LoRa event queue
extern void lora_isr_callback(void);

#endif // _LORA_H