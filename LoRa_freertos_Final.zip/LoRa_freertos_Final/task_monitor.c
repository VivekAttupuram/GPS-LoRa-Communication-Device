#include "task_monitor.h"

#include "hal.h"

void task_monitor_task(void *pvParameters)
{
    task_monitor_params_t *task_array_struct = (task_monitor_params_t *)pvParameters;
    UBaseType_t uxTaskWaterMark;

    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(5000)); // Wait for 5 seconds before checking again
        hal_printf("----------------------------------------\n");
        for (size_t n = 0; n < task_array_struct->num_tasks; n++)
        {
            const char *pcTaskName = pcTaskGetName(task_array_struct->task_array[n]);
            uxTaskWaterMark = uxTaskGetStackHighWaterMark(task_array_struct->task_array[n]);
            hal_printf("%s: High Water Mark: %lu words remaining\n", pcTaskName, uxTaskWaterMark);
        }

        // You can also check your own stack usage
        uxTaskWaterMark = uxTaskGetStackHighWaterMark(NULL);
        // This value will likely decrease after the printf calls use the stack
        hal_printf("Monitor Task: High Water Mark: %lu words remaining\n", uxTaskWaterMark);
        hal_printf("----------------------------------------\n");
    }
}