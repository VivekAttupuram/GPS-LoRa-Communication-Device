#include "nmea.h"

#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>

#define NMEA_TMP_BUFF_SIZE 32 // configures how much memory to put aside for our temp buffer

// --- "Private" typedef ---
// can only be used in this file
typedef enum // Tracks current GPS parser state
{
    SEEKING, // looking for a $
    PARSING  // extracting data
} nmea_parse_state_t;

// --- "Private" (file static) data ---
// can only be modified by other functions in this file
static char nmea_buff[NMEA_TMP_BUFF_SIZE];         // where we'll store fields temporarily.
static size_t nmea_buff_head = 0;                  // current index to write to
static nmea_parse_state_t current_state = SEEKING; // tracks what state the parser is in
static uint8_t fieldnum = 0;                       // tracks the current field number

// "Private" function below
// can only be used in this file.
// "static" is technically not necessary, but makes it clear that it is internal.

/// @brief When a null-terminated field is in nmea_buff,
///        this will extract data based on field value.
/// @param gga_data_p Data structure that is updated with extracted data.
static void parse_GGA_field(nmea_GGA_t *const gga_data_p);

// "Public" function
// declared extern previouly

bool nmea_parse(const char ch, nmea_GGA_t *const gga_data_p)
{
    static uint8_t checksum_internal = 0; // we XOR every character between (excluding) the $ and *
    bool new_data = false;                // when we have new data to process, make this a 1

    switch (current_state)
    {
    case SEEKING:
        // if we are SEEKING, find the $ and start PARSING
        // When you start parsing, reset everything to 0.
        // otherwise keep SEEKING
        if (ch == '$')
        {
            // printf("Found $!!!\n");
            current_state = PARSING;
            fieldnum = 0;
            nmea_buff_head = 0;
            checksum_internal = 0;
            memset(gga_data_p, 0, sizeof(nmea_GGA_t)); // reset gga_data to 0
        }
        break;

    case PARSING:
        // first check to make sure there's still room in the buffer
        if (nmea_buff_head >= NMEA_TMP_BUFF_SIZE)
        {
            current_state = SEEKING;
            printf("NMEA buffer overrun\n");
            break; // buffer overrun, just reset it
        }

        // next, if we have a *, we stop calculating the checksum and store it.
        if (ch == '*')
        {
            gga_data_p->checkcalc = checksum_internal;
        }

        // update the checksum. It is reset after $ and is saved at the *
        checksum_internal ^= (uint8_t)ch;

        // If we're at the end of a field, process it,  reset the buffer,
        // and increment the field number. Otherwise, just append it
        // to the buffer
        bool end_of_field = (ch == ',' || ch == '*' || ch == '\r');
        if (end_of_field == true)
        {
            nmea_buff[nmea_buff_head] = '\0';
            // printf("PROCESS field %d: %s\n", fieldnum, nmea_buff);
            parse_GGA_field(gga_data_p);
            nmea_buff_head = 0;
            fieldnum++;
        }
        else
        {
            nmea_buff[nmea_buff_head] = ch;
            nmea_buff_head++;
        }

        // if we're at the end of the sentence, reset to SEEKING,
        // update the validity flags, and return that we have new data
        bool end_of_sentence = (ch == '\r');
        if (end_of_sentence == true)
        {
            current_state = SEEKING;
            new_data = true;
            // set flags
            gga_data_p->valid_checksum = (gga_data_p->checksum == gga_data_p->checkcalc);
            gga_data_p->valid_gps_fix = (gga_data_p->gps_fix != NO_FIX);
            gga_data_p->valid_chksum_fix = (gga_data_p->valid_checksum && gga_data_p->valid_gps_fix);
        }
        break;

    default:
        break;
    }
    return new_data;
}

// Static functions
void parse_GGA_field(nmea_GGA_t *const gga_data_p)
{
    // we're going to use a bunch of strtod, strtol and similar
    // so let's gaurantee our buffer is null terminated
    nmea_buff[NMEA_TMP_BUFF_SIZE - 1] = '\0';

    // if the first character is '\0', don't do anything
    if (nmea_buff[0] != '\0')
    {
        switch (fieldnum)
        {
        case 0:
            if (strcmp(nmea_buff, "GNGGA") != 0)
            {
                current_state = SEEKING;
                fieldnum = 0;
                nmea_buff_head = 0;
                gga_data_p->checkcalc = 0;
            }
            break;
        case 1:
            // HHMMSS.SS
            // strtoul has error checking if conversion fails,
            // but it's ok in our case if it doesn't work, so we'll skip it
            // that the "NULL" as the second argument.
            gga_data_p->hour = strtoul(&nmea_buff[0], NULL, 10) / 10000U; // integer division in C truncates
            gga_data_p->min = strtoul(&nmea_buff[2], NULL, 10) / 100U;
            gga_data_p->sec = strtoul(&nmea_buff[4], NULL, 10);
            gga_data_p->hund_sec = strtoul(&nmea_buff[7], NULL, 10);
            break;
        case 2:
            // DDMM.MMMMM
            /// uint8_t latdeg = strtoul(&nmea_buff[0], NULL, 10) / 100U;
            gga_data_p->lat = strtoul(&nmea_buff[0], NULL, 10) / 100U + strtod(&nmea_buff[2], NULL) / 60.0; // decimal lat = degrees + mins/60
            break;
        case 3:
            if (nmea_buff[0] == 'S')
            {
                gga_data_p->lat = -1 * gga_data_p->lat;
            }
            break;
        case 4:
            // DDDMM.MMMMM
            // uint8_t londeg = strtoul(&nmea_buff[0], NULL, 10) / 100U;
            gga_data_p->lon = strtoul(&nmea_buff[0], NULL, 10) / 100U + strtod(&nmea_buff[3], NULL) / 60; // decimal lon = degrees + mins/60
            break;
        case 5:
            if (nmea_buff[0] == 'W')
            {
                gga_data_p->lon = -1 * gga_data_p->lon;
            }
            break;
        case 6:
            gga_data_p->gps_fix = (gps_fix_t)strtoul(&nmea_buff[0], NULL, 10);
            break;
        case 7:
            gga_data_p->num_sats = strtoul(nmea_buff, NULL, 10);
            break;
        case 8:
            gga_data_p->hdop = strtof(nmea_buff, NULL);
            break;
        case 9:
            gga_data_p->alt = strtof(nmea_buff, NULL);
            break;
        case 15:
            // use the 16 argument to strtoul to tell it it's a hex number!
            gga_data_p->checksum = strtoul(nmea_buff, NULL, 16);
            break;
        default:
            break;
        }
    }
}