#ifndef TASK_MONITOR_H
#define TASK_MONITOR_H

#include "FreeRTOS.h"
#include "task.h"

#define MAX_TASKS_MONITOR 16

typedef struct
{
    TaskHandle_t task_array[MAX_TASKS_MONITOR];
    size_t num_tasks; // number of tasks to check
} task_monitor_params_t;

extern void task_monitor_task(void *pvParameters);

#endif // TASK_MONITOR_H
