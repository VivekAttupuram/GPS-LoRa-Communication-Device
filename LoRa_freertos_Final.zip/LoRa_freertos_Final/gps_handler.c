#include "gps_handler.h"

#include <string.h>

#include "nmea.h"

#include "lora.h"
#include "hal.h"

static gps_handler_params_t *context; // make a static copy so the ISR can use it

void gps_handler_task(void *pvParameters)
{
    context = (gps_handler_params_t *)pvParameters;
    char ch;
    hal_gps_set_rx_irq(true);   // fire up the UART let's gooooooo!
    nmea_GGA_t nmea_data = {0}; // initialize to zeros
    while (true)
    {
        xQueueReceive(context->gps_queue_handle, &ch, portMAX_DELAY);
        // hal_stdio_putchar(ch); // for debugging
        bool ret = nmea_parse(ch, &nmea_data);
        if (ret && nmea_data.valid_chksum_fix)
        {
            hal_printf("\nseconds %u lat: %f lon: %f\n", nmea_data.sec, nmea_data.lat, nmea_data.lon);
            lora_msg_t lora_msg = {.event = TX_REQ_EVENT};
            uint8_t myID = 49; // my ID
            memcpy(&lora_msg.pkt.data[0], &myID, 1);
            memcpy(&lora_msg.pkt.data[1], &nmea_data.lat, 8);
            memcpy(&lora_msg.pkt.data[9], &nmea_data.lon, 8);
            lora_msg.pkt.len = 17;
            xQueueSend(context->loramanager_queue_handle, &lora_msg, 0); // don't wait
            vTaskDelay(pdMS_TO_TICKS(10000)); // sleeping for some time //one minute
        }
    }
}

void gps_handler_isr(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    while (hal_gps_is_readable())
    {
        char ch = hal_gps_getc();
        xQueueSendFromISR(context->gps_queue_handle, &ch, &xHigherPriorityTaskWoken);
    }
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
